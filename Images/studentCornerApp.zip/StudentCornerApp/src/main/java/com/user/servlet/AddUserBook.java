package com.user.servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.DAO.BookDAOImpl;
import com.DB.DBConnect;
import com.entity.BookDtls;

@WebServlet("/adduserbook")
  
public class AddUserBook extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		try {
			String bookname=req.getParameter("bname");
			String author=req.getParameter("author");
			String price =(req.getParameter("price"));
			String bookCategory =req.getParameter("category");
			String status="Active";
			Part  part = req.getPart("bimg");
			String fileName=part.getSubmittedFileName();
			
			String useremail=req.getParameter("user");
			
	        BookDtls b =new BookDtls(bookname,author,price,bookCategory,status,fileName,useremail);
	        
	        BookDAOImpl dao=new BookDAOImpl(DBConnect.getConn());
	        
	        
	       
	       
	       
	        
	        boolean f = dao.addBook(b);
	        
	        HttpSession session =req.getSession();
	        
        if(f) {
        	
	        	String Path = getServletContext().getRealPath("")+"book";
	        	
	        	File file = new File(Path);
	        	
	        	part.write(Path +File.separator+fileName);
	        	
        	session.setAttribute("succMsg", "BOOK ADDED SUCCUSFULLY");
	        	resp.sendRedirect("sellbook.jsp");
	        			
	        }else {
	        	
	        	session.setAttribute("faildMsg", "Something Wrong");
        	resp.sendRedirect("sellbook.jsp");
        }
	        
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}


