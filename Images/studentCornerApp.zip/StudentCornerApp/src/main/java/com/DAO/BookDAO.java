package com.DAO;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;

import com.entity.BookDtls;
@MultipartConfig
public interface BookDAO {

	public boolean addBook(BookDtls b);
	
	public  List<BookDtls> getAllBooks();
	
	public BookDtls getBookById(int id);
	
	public boolean updateEditBook(BookDtls b);
	
	public boolean deleteBooks(int id);
	
	public List<BookDtls>getNewBook();
	
	
	
	public List<BookDtls>getRecentBook();
	
	public List<BookDtls>getOldBook();
	
	
	
	public List<BookDtls>getAllRecentBook();
	public List<BookDtls>getALLNewBook();
	public List<BookDtls>getALLOldBook();
	
	
	//notes
	
	
	
	
	//notes end
	
//userbookDelete
	
	public List<BookDtls> getBookByCategory(String email);
	
	
	public boolean userBookDelet(int id);

//end
	
	//search book
	
	public List<BookDtls> getBookBySearch(String ch);
	
}



